// Pure Kotlin/JVM module: no Android and no data layer on the classpath.
// (If New Module generated a build file with alias(libs.plugins....), keep it and
// only make sure the Java/Kotlin JVM target matches the app module.)
plugins {
    id("java-library")
    id("org.jetbrains.kotlin.jvm")
}

java {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_11)
    }
}
